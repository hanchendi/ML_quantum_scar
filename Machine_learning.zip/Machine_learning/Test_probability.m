clear
clc

load('shot1_class6_size100_confusion_pred.mat')
load('shot1_class6_size100_probability_pred.mat')

index=1201;
disp(confusion_pred(index,:));
temp=probability_pred(index,:,:);
temp=reshape(temp,6,6);
disp(temp)

row_index=3;
norm=0;
for i=1:6
    norm=norm+exp(temp(row_index,i));
end
temp2=zeros(1,6);
for i=1:6
    temp2(i)=exp(temp(row_index,i))/norm;
end
temp2