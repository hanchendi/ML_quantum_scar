"""
Train a model on Omniglot.
"""

import random

import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()

from supervised_reptile.args import argument_parser, model_kwargs, train_kwargs, evaluate_kwargs
from supervised_reptile.eval import evaluate, evaluate_sweep
from supervised_reptile.models import OmniglotModel
from supervised_reptile.omniglot import read_dataset_train, read_dataset_test,read_dataset_sweep ,augment_dataset
from supervised_reptile.train import train

DATA_DIR1 = 'data/omniglot_revised'
DATA_DIR2 = 'data/scar_sweep/Heart'
DATA_DIR3 = 'data/sweep'

def main():
    """
    Load data and train a model on it.
    """
    args = argument_parser().parse_args()
    random.seed(args.seed)
    
    train_set=list(read_dataset_train(DATA_DIR1))
    train_set = list(augment_dataset(train_set))
    
    test_set=list(read_dataset_test(DATA_DIR2))
    test_set = list(test_set)
     
    with open("label.txt", "w") as f:
        for i, item in enumerate(test_set):
            f.write(item.dir_path+' '+str(i) +"\n")
    
    sweep_set=list(read_dataset_sweep(DATA_DIR3))
    for i,item in enumerate(sweep_set):
        print(item.dir_path)
    
    model = OmniglotModel(args.classes, **model_kwargs(args))
    print(sweep_set)
    with tf.Session() as sess:
        #if not args.pretrained:
            #print('Training...')
        #train(sess, model, train_set, test_set, args.checkpoint, **train_kwargs(args))
        #else:
        #print('Restoring from checkpoint...')
        #saver = tf.train.import_meta_graph('./model_checkpoint/model.ckpt-0.meta')
        #saver.restore(sess, "./model_checkpoint/model.ckpt-0")
        tf.train.Saver().restore(sess, tf.train.latest_checkpoint(args.checkpoint))
        print('Evaluating...')
        eval_kwargs = evaluate_kwargs(args)
        #print('Train accuracy: ' + str(evaluate(sess, model, train_set, **eval_kwargs)))
        #print('Test accuracy: ' + str(evaluate(sess, model, test_set, **eval_kwargs)))
        evaluate_sweep(sess, model, test_set,sweep_set, **eval_kwargs)

if __name__ == '__main__':
    main()
