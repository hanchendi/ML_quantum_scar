"""
Helpers for evaluating models.
"""
import os
cwd=os.getcwd()
import scipy.io
import numpy as np

from .reptile import Reptile
from .variables import weight_decay

# pylint: disable=R0913,R0914
def evaluate(sess,
             model,
             dataset,
             num_classes=5,
             num_shots=5,
             eval_inner_batch_size=5,
             eval_inner_iters=50,
             replacement=False,
             num_samples=10000,
             transductive=False,
             weight_decay_rate=1,
             reptile_fn=Reptile):
    """
    Evaluate a model on a dataset.
    """
    reptile = reptile_fn(sess,
                         transductive=transductive,
                         pre_step_op=weight_decay(weight_decay_rate))
    total_correct = 0
    for _ in range(num_samples):
        total_correct += reptile.evaluate_train(dataset, model.input_ph, model.label_ph,
                                          model.minimize_op, model.predictions,model.logits,
                                          num_classes=num_classes, num_shots=num_shots,
                                          inner_batch_size=eval_inner_batch_size,
                                          inner_iters=eval_inner_iters, replacement=replacement)
        print(total_correct)
    return total_correct / (num_samples * num_classes)

def evaluate_sweep(sess,
             model,
             dataset,
             dataset_sweep,
             num_classes=5,
             num_shots=5,
             eval_inner_batch_size=5,
             eval_inner_iters=50,
             replacement=False,
             num_samples=10000,
             transductive=False,
             weight_decay_rate=1,
             reptile_fn=Reptile):
    """
    Evaluate a model on a dataset.
    """
    reptile = reptile_fn(sess,
                         transductive=transductive,
                         pre_step_op=weight_decay(weight_decay_rate))
    probability_pred=np.zeros([num_samples,15000,num_classes])
    print(cwd)
    for i in range(num_samples):
        temp= reptile.evaluate_sweep(dataset,dataset_sweep, model.input_ph, model.label_ph,
                                          model.minimize_op, model.predictions,model.logits,
                                          num_classes=num_classes, num_shots=num_shots,
                                          inner_batch_size=eval_inner_batch_size,
                                          inner_iters=eval_inner_iters, replacement=replacement)
        for j1 in range(0,15000):
            for j2 in range(0,num_classes):
                probability_pred[i][j1][j2]=temp[j1][j2]
        print(i)
        scipy.io.savemat(cwd+'_probability_pred.mat', mdict={'probability_pred': probability_pred})
    return num_samples
