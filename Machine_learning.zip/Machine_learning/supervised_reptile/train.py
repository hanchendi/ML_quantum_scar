"""
Training helpers for supervised meta-learning.
"""
import os
cwd=os.getcwd()
import scipy.io
import time
import numpy as np
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()

from .reptile import Reptile
from .variables import weight_decay

# pylint: disable=R0913,R0914
def train(sess,
          model,
          train_set,
          test_set,
          save_dir,
          num_classes=20,
          num_shots=1,
          inner_batch_size=20,
          inner_iters=20,
          replacement=False,
          meta_step_size=0.1,
          meta_step_size_final=0.1,
          meta_batch_size=1,
          meta_iters=400000,
          eval_inner_batch_size=5,
          eval_inner_iters=50,
          eval_interval=10,
          weight_decay_rate=1,
          time_deadline=None,
          train_shots=None,
          transductive=False,
          reptile_fn=Reptile,
          log_fn=print):
    """
    Train a model on a dataset.
    """
    if not os.path.exists(save_dir):
        os.mkdir(save_dir)
    saver = tf.train.Saver()
    reptile = reptile_fn(sess,
                         transductive=transductive,
                         pre_step_op=weight_decay(weight_decay_rate))
    accuracy_ph = tf.placeholder(tf.float32, shape=())
    tf.summary.scalar('accuracy', accuracy_ph)
    merged = tf.summary.merge_all()
    train_writer = tf.summary.FileWriter(os.path.join(save_dir, 'train'), sess.graph)
    test_writer = tf.summary.FileWriter(os.path.join(save_dir, 'test'), sess.graph)
    tf.global_variables_initializer().run()
    sess.run(tf.global_variables_initializer())
    
    result=np.zeros([meta_iters//eval_interval,3])
    confusion_real=np.zeros([meta_iters//eval_interval,num_classes])
    confusion_pred=np.zeros([meta_iters//eval_interval,num_classes])
    probability_pred=np.zeros([meta_iters//eval_interval,num_classes,num_classes])
    print('num_classes:',num_classes)
    print('num_shot:',num_shots)
    for i in range(meta_iters):
        #print(i)
        frac_done = i / meta_iters
        cur_meta_step_size = frac_done * meta_step_size_final + (1 - frac_done) * meta_step_size
        reptile.train_step(train_set, model.input_ph, model.label_ph, model.minimize_op,
                           num_classes=num_classes, num_shots=train_shots,
                           inner_batch_size=inner_batch_size, inner_iters=inner_iters,
                           replacement=replacement,
                           meta_step_size=cur_meta_step_size, meta_batch_size=meta_batch_size)
        if i % eval_interval == 0:
            accuracy=[]
            correct = reptile.evaluate_train(train_set, model.input_ph, model.label_ph,
                                       model.minimize_op, model.predictions,model.logits,
                                       num_classes=num_classes, num_shots=num_shots,
                                       inner_batch_size=eval_inner_batch_size,
                                       inner_iters=eval_inner_iters, replacement=replacement)
                #summary = sess.run(merged, feed_dict={accuracy_ph: correct/num_classes})
                #writer.add_summary(summary, i)
                #writer.flush()
            accuracy.append(correct / num_classes)
            
            real_label,pred_label, pred_probability = reptile.evaluate_test(test_set, model.input_ph, model.label_ph,
                                       model.minimize_op, model.predictions,model.logits,
                                       num_classes=num_classes, num_shots=num_shots,
                                       inner_batch_size=eval_inner_batch_size,
                                       inner_iters=eval_inner_iters, replacement=replacement)
            accuracy.append(sum([real_label[j]==pred_label[j] for j in range(0,num_classes)])/num_classes)
            
            temp_dir="/shot1_class6_size100"
            result[i//eval_interval][0],result[i//eval_interval][1],result[i//eval_interval][2]=i,accuracy[0],accuracy[1]
            for j in range(0,num_classes):
                confusion_real[i//eval_interval][j]=real_label[j]
                confusion_pred[i//eval_interval][j]=pred_label[j]
            for j1 in range(0,num_classes):
                for j2 in range(0,num_classes):
                    probability_pred[i//eval_interval][j1][j2]=pred_probability[j1][j2]
            scipy.io.savemat(cwd+temp_dir+'_accuracy.mat', mdict={'result': result})
            scipy.io.savemat(cwd+temp_dir+'_confusion_real.mat', mdict={'confusion_real': confusion_real})
            scipy.io.savemat(cwd+temp_dir+'_confusion_pred.mat', mdict={'confusion_pred': confusion_pred})
            scipy.io.savemat(cwd+temp_dir+'_probability_pred.mat', mdict={'probability_pred': probability_pred})
            print(i, "%.3f" % accuracy[0],  "%.3f" % accuracy[1])
        if i % 100 == 0 or i == meta_iters-1:
            saver.save(sess, os.path.join(save_dir, 'model.ckpt'), global_step=i)
        #if time_deadline is not None and time.time() > time_deadline:
        #    break
