clear
clc

folder1 = dir('omniglot');
n1=size( struct2table(folder1),  1);
for i1=3:n1
    folder2=dir(['omniglot/',folder1(i1).name]);
    n2=size( struct2table(folder2),  1);
    for i2=3:n2
        folder3=dir(['omniglot/',folder1(i1).name,'/',folder2(i2).name]);
        n3=size( struct2table(folder3),  1);
        for i3=3:n3
            original_figure=imread(['omniglot/',folder1(i1).name,'/',folder2(i2).name,'/',folder3(i3).name]);
            revised_figure=convert_fun(original_figure);
            imwrite(revised_figure, ['omniglot_revised/',folder1(i1).name,'/',folder2(i2).name,'/',folder3(i3).name]);
%             figure()
%             subplot(1,2,1)
%             mesh(original_figure)
%             subplot(1,2,2)
%             mesh(revised_figure)
        end
        disp([i1/n1,i2/n2])
    end
end
% original_figure=imread('0394_01.png');
% revised_figure=convert_fun(original_figure);
% imwrite(revised_figure, 'test.png');