function revised_figure = convert_fun(original_figure)
original_figure=1-original_figure;
test=zeros(232,232);
for i=1:210
    for j=1:210
        temp=original_figure(floor(i/2)+mod(i,2),floor(j/2)+mod(j,2));
        test(i+11,j+11)=temp;
        test(i+1+11,j+11)=temp;
        test(i+11,j+1+11)=temp;
        test(i+1+11,j+1+11)=temp;
    end
end
test=test+rand(232,232);
temp=fft2(test);
for i=1:232
    for j=1:232
        if i>210 || j>210
            temp(i,j)=0;
        end
    end
end

revised_figure = real(ifft2(temp,232,232));
    x=revised_figure;
    [~,idx] = sort(x(:));
    y_max=x(idx(length(idx)-2000));
    for j1=1:232
        for j2=1:232
            if revised_figure(j1,j2)>y_max
                revised_figure(j1,j2)=0;
            else
                revised_figure(j1,j2)=1;
            end
        end
    end
    
   revised_figure = logical(revised_figure);
end

