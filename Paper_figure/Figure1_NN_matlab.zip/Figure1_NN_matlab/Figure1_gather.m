clear
clc

L=[102 178 255;
    153 204 255;
    204 229 255;
255 229 204;
255 204 153;
255 178 102;
255 153 51
255 128 0]./255;

interval=[30 15 5 15 30 30 50];
mycolor=[];
for i=1:7
    temp=[];
    for j=1:3
        temp(:,j)=linspace(L(i,j),L(i+1,j),interval(i));
    end
    mycolor=[mycolor;temp];
end

subplot('Position',[0.1 0.85 0.12 0.14]);
load('psi_0.5_8480.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.1 0.68 0.12 0.14]);
load('psi_0.5_8523.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.3 0.67 0.63 0.33]);


fill([0 1 1 0]-0.4,[0 0 1 1]+0.4,[1 1 1],'linewidth',0.5);hold on
fill([0 1 1 0]-0.2,[0 0 1 1]+0.2,[204 229 255]/255,'linewidth',0.5);hold on
fill([0 1 1 0],[0 0 1 1],[1 1 1],'linewidth',0.5);hold on

fill([0 0.8 0.8 0]+1.3,[0 0 0.8 0.8]+0.8,[1 1 1],'linewidth',0.5);hold on
fill([0 0.8 0.8 0]+1.425,[0 0 0.8 0.8]+0.55,[204 229 255]/255,'linewidth',0.5);hold on
fill([0 0.8 0.8 0]+1.55,[0 0 0.8 0.8]+0.3,[1 1 1],'linewidth',0.5);hold on
fill([0 0.8 0.8 0]+1.675,[0 0 0.8 0.8]+0.05,[204 229 255]/255,'linewidth',0.5);hold on
fill([0 0.8 0.8 0]+1.8,[0 0 0.8 0.8]-0.2,[1 1 1],'linewidth',0.5);hold on

plot([0.6 0.9 0.9 0.6 0.6],[0.6 0.6 0.9 0.9 0.6],'k');hold on

plot(1.8,0.96,'k.','markersize',15);hold on
plot([0.9 1.8],[0.9 0.96],'k');hold on
plot([0.9 1.8],[0.6 0.96],'k');hold on

% rectangle 1
xmin=-0.5;
xmax=2.7;
ymin=-0.5;
ymax=2;
r_rec=0.3;
theta1=linspace(0,pi/2);
theta2=linspace(pi/2,pi);
theta3=linspace(pi,3*pi/2);
theta4=linspace(3*pi/2,2*pi);
plot([xmin+r_rec xmax-r_rec],[ymin ymin],'k--');hold on
plot([xmin+r_rec xmax-r_rec],[ymax ymax],'k--');hold on
plot([xmin xmin],[ymin+r_rec ymax-r_rec],'k--');hold on
plot([xmax xmax],[ymin+r_rec ymax-r_rec],'k--');hold on

plot(cos(theta1)*r_rec+xmax-r_rec,sin(theta1)*r_rec+ymax-r_rec,'k--');hold on
plot(cos(theta2)*r_rec+xmin+r_rec,sin(theta2)*r_rec+ymax-r_rec,'k--');hold on
plot(cos(theta3)*r_rec+xmin+r_rec,sin(theta3)*r_rec+ymin+r_rec,'k--');hold on
plot(cos(theta4)*r_rec+xmax-r_rec,sin(theta4)*r_rec+ymin+r_rec,'k--');hold on

% rectangle 2
xmin=3.2;
xmax=3.5;
ymin=-0.6;
ymax=2;
r_rec=0.15;
theta1=linspace(0,pi/2);
theta2=linspace(pi/2,pi);
theta3=linspace(pi,3*pi/2);
theta4=linspace(3*pi/2,2*pi);
plot([xmin+r_rec xmax-r_rec],[ymin ymin],'k');hold on
plot([xmin+r_rec xmax-r_rec],[ymax ymax],'k');hold on
plot([xmin xmin],[ymin+r_rec ymax-r_rec],'k');hold on
plot([xmax xmax],[ymin+r_rec ymax-r_rec],'k');hold on

plot(cos(theta1)*r_rec+xmax-r_rec,sin(theta1)*r_rec+ymax-r_rec,'k');hold on
plot(cos(theta2)*r_rec+xmin+r_rec,sin(theta2)*r_rec+ymax-r_rec,'k');hold on
plot(cos(theta3)*r_rec+xmin+r_rec,sin(theta3)*r_rec+ymin+r_rec,'k');hold on
plot(cos(theta4)*r_rec+xmax-r_rec,sin(theta4)*r_rec+ymin+r_rec,'k');hold on

for i=1:7
    plot(xmin+r_rec,0.7+0.35*(i-4),'k.','markersize',15);hold on
end
% circle center 0.7
r_cir=0.2;
theta0=linspace(0,2*pi);
fill(cos(theta0)*r_cir+4.2,sin(theta0)*r_cir+1.45,[224 224 224]/255);hold on
fill(cos(theta0)*r_cir+4.2,sin(theta0)*r_cir+0.95,[224 224 224]/255);hold on
fill(cos(theta0)*r_cir+4.2,sin(theta0)*r_cir+0.45,[224 224 224]/255);hold on
fill(cos(theta0)*r_cir+4.2,sin(theta0)*r_cir-0.05,[224 224 224]/255);hold on

for i=1:7
    plot([xmin+r_rec 4.2-r_cir],[0.7+0.35*(i-4) 1.45],'k');hold on
    plot([xmin+r_rec 4.2-r_cir],[0.7+0.35*(i-4) 0.95],'k');hold on
    plot([xmin+r_rec 4.2-r_cir],[0.7+0.35*(i-4) 0.45],'k');hold on
    plot([xmin+r_rec 4.2-r_cir],[0.7+0.35*(i-4) -0.05],'k');hold on
end

axis([-0.51 4.41 ymin-0.01 ymax+0.01])
axis off

%%

L=[102 178 255;
    153 204 255;
    204 229 255;
255 229 204;
255 204 153;
255 178 102;
255 153 51
255 128 0]./255;

interval=[30 15 5 15 30 30 50];
mycolor=[];
for i=1:7
    temp=[];
    for j=1:3
        temp(:,j)=linspace(L(i,j),L(i+1,j),interval(i));
    end
    mycolor=[mycolor;temp];
end

subplot('Position',[0.13 0.47 0.12 0.14]);
load('psi_0.5_5925.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([1 232],[88 88],'--','color',[0.3 0.3 0.3]);hold on
axis off
view([90 -90])
text(0.35,1.15,'II','Units', 'Normalized','fontsize',14)

subplot('Position',[0.27 0.47 0.12 0.14]);
load('psi_0.5_8292.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([219 15],[46 44],'--','color',[0.3 0.3 0.3]);hold on
plot([219 115],[46 201],'--','color',[0.3 0.3 0.3]);hold on
plot([15 115],[46 201],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.31,1.15,'III','Units', 'Normalized','fontsize',14)

subplot('Position',[0.41 0.47 0.12 0.14]);
load('psi_0.5_8480.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([206 27],[26 26],'--','color',[0.3 0.3 0.3]);hold on
plot([202 32],[167 167],'--','color',[0.3 0.3 0.3]);hold on
plot([206 202],[26 167],'--','color',[0.3 0.3 0.3]);hold on
plot([27 32],[26 167],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.23,1.15,'IV-1','Units', 'Normalized','fontsize',14)

subplot('Position',[0.55 0.47 0.12 0.14]);
load('psi_0.5_10077.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([173 115],[5 201],'--','color',[0.3 0.3 0.3]);hold on
plot([57 115],[5 201],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.23,1.15,'IV-2','Units', 'Normalized','fontsize',14)

subplot('Position',[0.69 0.47 0.12 0.14]);
load('psi_0.5_5905.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([205 117],[25 201],'--','color',[0.3 0.3 0.3]);hold on
plot([29 117],[25 201],'--','color',[0.3 0.3 0.3]);hold on
plot([232 2],[100 100],'--','color',[0.3 0.3 0.3]);hold on
plot([205 2],[25 100],'--','color',[0.3 0.3 0.3]);hold on
plot([31 232],[25 100],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.26,1.15,'V-1','Units', 'Normalized','fontsize',14)

subplot('Position',[0.83 0.47 0.12 0.14]);
load('psi_0.5_9523.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([146 115],[3 201],'--','color',[0.3 0.3 0.3]);hold on
plot([115 84],[201 16],'--','color',[0.3 0.3 0.3]);hold on
plot([84 16],[3 149],'--','color',[0.3 0.3 0.3]);hold on
plot([214 16],[149 149],'--','color',[0.3 0.3 0.3]);hold on
plot([214 149],[146 16],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.26,1.15,'V-2','Units', 'Normalized','fontsize',14)

%%
subplot('Position',[0.11 0.06 0.87 0.4]);
load('probability_sweep_050.mat')
index1=8480;
index2=8523;

A=ones(10,6);
B=ones(10,6);
for i=1:10

        p=probability_sweep(i,index1,:);
        p=reshape(p,[1,6]);
        norm=0;
        for k=1:6
            norm=norm+exp(p(k));
        end
        p_norm=zeros(1,6);
        for k=1:6
            p_norm(k)=exp(p(k))/norm;
        end
        for k=1:6
            A(i,k)=A(i,k)*p_norm(k);
        end
   
        p=probability_sweep(i,index2,:);
        p=reshape(p,[1,6]);
        norm=0;
        for k=1:6
            norm=norm+exp(p(k));
        end
        p_norm=zeros(1,6);
        for k=1:6
            p_norm(k)=exp(p(k))/norm;
        end
        for k=1:6
            B(i,k)=B(i,k)*p_norm(k);
        end
end

%%
A_average=zeros(1,6);
A_sigma=zeros(1,6);
for i=1:6
    A_average(i)=mean(A(:,i));
    A_sigma(i)=sqrt(sum((A(:,i)-A_average(i)).^2)/10);
end
for i=1:6
    h1=fill([i-0.3 i i i-0.3],[-1 -1 A_average(i) A_average(i)],[174 199 232]/255);hold on
end
errorbar([1:6]-0.15,A_average,A_sigma,'linestyle','None','linewidth',1.5,'color',[31 119 180]/255);hold on

%%
B_average=zeros(1,6);
B_sigma=zeros(1,6);
for i=1:6
    B_average(i)=mean(B(:,i));
    B_sigma(i)=sqrt(sum((B(:,i)-B_average(i)).^2)/10);
end

for i=1:6
    h2=fill([i i+0.3 i+0.3 i],[-1 -1 B_average(i) B_average(i)],[255 187 120]/255);hold on
end
errorbar([1:6]+0.15,B_average,B_sigma,'linestyle','None','linewidth',1.5,'color',[255 127 14]/255);hold on
axis([0.4 6.6 0 1.01])
h=legend([h1,h2],'n=8480','n=8523');
set(h,'interpreter','latex')
set(gca,'fontsize',14)
ylabel('$p$','interpreter','latex')
xticklabels({'II','III','IV-1','IV-2','V-1','V-2'})
text(-0.12,2.3,'(a)','Units', 'Normalized','fontsize',17)
text(-0.12,1.43,'(b)','Units', 'Normalized','fontsize',17)
text(-0.12,1,'(c)','Units', 'Normalized','fontsize',17)
text(0.41,2.29,'CNN','Units', 'Normalized','fontsize',17)

axPos = get(gca,'Position');
xMinMax = xlim;
yMinMax = ylim;
x1Annotation = axPos(1) + ((1 - xMinMax(1))/(xMinMax(2)-xMinMax(1))) * axPos(3);
x2Annotation = axPos(1) + ((2  - xMinMax(1))/(xMinMax(2)-xMinMax(1))) * axPos(3);
y1Annotation = axPos(2) + ((0 - yMinMax(1))/(yMinMax(2)-yMinMax(1))) * axPos(4);
y2Annotation = axPos(2) + ((0.5 - yMinMax(1))/(yMinMax(2)-yMinMax(1))) * axPos(4);
annotation('textarrow',[x1Annotation x2Annotation],[y1Annotation y2Annotation],'HeadStyle','plain','HeadLength',9,'HeadWidth',9);

set(gcf,'position',[100 100 500 500])