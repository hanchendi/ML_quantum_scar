clear
clc

fill([0 1 1 0]-0.4,[0 0 1 1]+0.4,[1 1 1],'linewidth',0.5);hold on
fill([0 1 1 0]-0.2,[0 0 1 1]+0.2,[1 1 1],'linewidth',0.5);hold on
fill([0 1 1 0],[0 0 1 1],[1 1 1],'linewidth',0.5);hold on


fill([0 0.8 0.8 0]+1.3,[0 0 0.8 0.8]+0.8,[1 1 1],'linewidth',0.5);hold on
fill([0 0.8 0.8 0]+1.425,[0 0 0.8 0.8]+0.55,[1 1 1],'linewidth',0.5);hold on
fill([0 0.8 0.8 0]+1.55,[0 0 0.8 0.8]+0.3,[1 1 1],'linewidth',0.5);hold on
fill([0 0.8 0.8 0]+1.675,[0 0 0.8 0.8]+0.05,[1 1 1],'linewidth',0.5);hold on
fill([0 0.8 0.8 0]+1.8,[0 0 0.8 0.8]-0.2,[1 1 1],'linewidth',0.5);hold on

plot([0.6 0.9 0.9 0.6 0.6],[0.6 0.6 0.9 0.9 0.6],'k');hold on

plot(1.8,0.96,'k.','markersize',15);hold on
plot([0.9 1.8],[0.9 0.96],'k');hold on
plot([0.9 1.8],[0.6 0.96],'k');hold on

% rectangle 1
xmin=-0.45;
xmax=2.65;
ymin=-0.23;
ymax=1.63;
r_rec=0.2;
theta1=linspace(0,pi/2);
theta2=linspace(pi/2,pi);
theta3=linspace(pi,3*pi/2);
theta4=linspace(3*pi/2,2*pi);
plot([xmin+r_rec xmax-r_rec],[ymin ymin],'k');hold on
plot([xmin+r_rec xmax-r_rec],[ymax ymax],'k');hold on
plot([xmin xmin],[ymin+r_rec ymax-r_rec],'k');hold on
plot([xmax xmax],[ymin+r_rec ymax-r_rec],'k');hold on

plot(cos(theta1)*r_rec+xmax-r_rec,sin(theta1)*r_rec+ymax-r_rec,'k');hold on
plot(cos(theta2)*r_rec+xmin+r_rec,sin(theta2)*r_rec+ymax-r_rec,'k');hold on
plot(cos(theta3)*r_rec+xmin+r_rec,sin(theta3)*r_rec+ymin+r_rec,'k');hold on
plot(cos(theta4)*r_rec+xmax-r_rec,sin(theta4)*r_rec+ymin+r_rec,'k');hold on

% rectangle 2
xmin=2.9;
xmax=3.2;
ymin=-0.6;
ymax=2;
r_rec=0.15;
theta1=linspace(0,pi/2);
theta2=linspace(pi/2,pi);
theta3=linspace(pi,3*pi/2);
theta4=linspace(3*pi/2,2*pi);
plot([xmin+r_rec xmax-r_rec],[ymin ymin],'k');hold on
plot([xmin+r_rec xmax-r_rec],[ymax ymax],'k');hold on
plot([xmin xmin],[ymin+r_rec ymax-r_rec],'k');hold on
plot([xmax xmax],[ymin+r_rec ymax-r_rec],'k');hold on

plot(cos(theta1)*r_rec+xmax-r_rec,sin(theta1)*r_rec+ymax-r_rec,'k');hold on
plot(cos(theta2)*r_rec+xmin+r_rec,sin(theta2)*r_rec+ymax-r_rec,'k');hold on
plot(cos(theta3)*r_rec+xmin+r_rec,sin(theta3)*r_rec+ymin+r_rec,'k');hold on
plot(cos(theta4)*r_rec+xmax-r_rec,sin(theta4)*r_rec+ymin+r_rec,'k');hold on

for i=1:4
    plot(xmin+r_rec,ymax-0.2*i,'k.','markersize',15);hold on
    plot(xmin+r_rec,ymin+0.2*i,'k.','markersize',15);hold on
end
% circle center 0.7
r_cir=0.2;
theta0=linspace(0,2*pi);
plot(cos(theta0)*r_cir+3.7,sin(theta0)*r_cir+1.45,'k');hold on
plot(cos(theta0)*r_cir+3.7,sin(theta0)*r_cir+0.95,'k');hold on
plot(cos(theta0)*r_cir+3.7,sin(theta0)*r_cir+0.45,'k');hold on
plot(cos(theta0)*r_cir+3.7,sin(theta0)*r_cir-0.05,'k');hold on



%axis([-0.41 2.61 -0.21 1.61])
axis off
set(gcf,'position',[100 100 500 400])