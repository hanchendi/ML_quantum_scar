clear
clc

load('probability_sweep_050.mat')
index1=8480;
index2=8523;

A=ones(10,6);
B=ones(10,6);
for i=1:10

        p=probability_sweep(i,index1,:);
        p=reshape(p,[1,6]);
        norm=0;
        for k=1:6
            norm=norm+exp(p(k));
        end
        p_norm=zeros(1,6);
        for k=1:6
            p_norm(k)=exp(p(k))/norm;
        end
        for k=1:6
            A(i,k)=A(i,k)*p_norm(k);
        end
   
        p=probability_sweep(i,index2,:);
        p=reshape(p,[1,6]);
        norm=0;
        for k=1:6
            norm=norm+exp(p(k));
        end
        p_norm=zeros(1,6);
        for k=1:6
            p_norm(k)=exp(p(k))/norm;
        end
        for k=1:6
            B(i,k)=B(i,k)*p_norm(k);
        end
end

%%
A_average=zeros(1,6);
A_sigma=zeros(1,6);
for i=1:6
    A_average(i)=mean(A(:,i));
    A_sigma(i)=sqrt(sum((A(:,i)-A_average(i)).^2)/10);
end
figure()
for i=1:6
    h1=fill([i-0.3 i i i-0.3],[-1 -1 A_average(i) A_average(i)],[174 199 232]/255);hold on
end
errorbar([1:6]-0.15,A_average,A_sigma,'linestyle','None','linewidth',1.5,'color',[31 119 180]/255);hold on

%%
B_average=zeros(1,6);
B_sigma=zeros(1,6);
for i=1:6
    B_average(i)=mean(B(:,i));
    B_sigma(i)=sqrt(sum((B(:,i)-B_average(i)).^2)/10);
end

for i=1:6
    h2=fill([i i+0.3 i+0.3 i],[-1 -1 B_average(i) B_average(i)],[255 187 120]/255);hold on
end
errorbar([1:6]+0.15,B_average,B_sigma,'linestyle','None','linewidth',1.5,'color',[255 127 14]/255);hold on
axis([0.4 6.6 0 1.01])
h=legend([h1,h2],'n=8480','n=8523');
set(h,'interpreter','latex')
set(gca,'fontsize',15)
ylabel('$p$','interpreter','latex')
xticklabels({'II','III','IV-1','IV-2','V-1','V-2'})
p1=ones(1,6);
p2=ones(1,6);
for i=1:10
    for j=1:6
        p1(j)=p1(j)*A(i,j);
        p2(j)=p2(j)*B(i,j);
    end
end
disp(max(p1))
disp(max(p2))