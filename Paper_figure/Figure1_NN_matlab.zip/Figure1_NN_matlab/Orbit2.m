clear
clc

load('psi_0.5_5925.mat')
figure(1)
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;

L=[102 178 255;
    153 204 255;
    204 229 255;
255 229 204;
255 204 153;
255 178 102;
255 153 51
255 128 0]./255;

interval=[30 15 5 15 30 30 50];
mycolor=[];
for i=1:7
    temp=[];
    for j=1:3
        temp(:,j)=linspace(L(i,j),L(i+1,j),interval(i));
    end
    mycolor=[mycolor;temp];
end

colormap(mycolor);

hold on
plot([1 232],[88 88],'r--')

view([90 -90])
axis off
axis equal
set(gca,'LooseInset',get(gca,'TightInset'));