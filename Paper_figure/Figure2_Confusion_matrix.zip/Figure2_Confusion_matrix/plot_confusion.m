clear
clc

%%

subplot('Position',[0.19 0.59 0.6 0.4]);
load('confusion_matrix_shot1.mat')
M=confusion_matrix;
for i=1:6
    for j=1:6
        M(i,j)=M(i,j)/10^4;
    end
end

for i=1:6
    for j=1:6
        c1=M(i,j);
        fill([-0.5+i 0.5+i 0.5+i -0.5+i ],[-0.5+j -0.5+j 0.5+j 0.5+j ],[1-c1,1-c1,1]);hold on
    end
end
axis([0.5 6.5 0.5 6.5])
%colorbar
mycolors(1:100,1)=linspace(1,0);
mycolors(1:100,2)=linspace(1,0);
mycolors(1:100,3)=ones(1,100);
colormap(mycolors);
%caxis([0,100])
xticklabels({'II','III','IV-1','IV-2','V-1','V-2'})
yticklabels({'II','III','IV-1','IV-2','V-1','V-2'})
xlabel('real','interpreter','latex')
ylabel('predict','interpreter','latex')
text(-0.3,1,'(a)','Units', 'Normalized','fontsize',17)
set(gca,'fontsize',14)

subplot('Position',[0.19 0.09 0.6 0.4]);
load('confusion_matrix_shot5.mat')
M=confusion_matrix;
for i=1:6
    for j=1:6
        M(i,j)=M(i,j)/10^4;
    end
end

for i=1:6
    for j=1:6
        c1=M(i,j);
        fill([-0.5+i 0.5+i 0.5+i -0.5+i ],[-0.5+j -0.5+j 0.5+j 0.5+j ],[1-c1,1-c1,1]);hold on
    end
end
axis([0.5 6.5 0.5 6.5])
colorbar('XTick',0:20:100,'XTickLabel',{'0%','20%','40%','60%','80%','100%'});
mycolors(1:100,1)=linspace(1,0);
mycolors(1:100,2)=linspace(1,0);
mycolors(1:100,3)=ones(1,100);
colormap(mycolors);
caxis([0,100])
xticklabels({'II','III','IV-1','IV-2','V-1','V-2'})
yticklabels({'II','III','IV-1','IV-2','V-1','V-2'})
xlabel('real','interpreter','latex')
ylabel('predict','interpreter','latex')
text(-0.3,1,'(b)','Units', 'Normalized','fontsize',17)
text(1,1,'Probability','Units', 'Normalized','fontsize',14,'interpreter','latex')
set(gca,'fontsize',14)
set(gcf,'position',[100 100 500 600])