clear
clc


L=[102 178 255;
    153 204 255;
    204 229 255;
255 229 204;
255 204 153;
255 178 102;
255 153 51
255 128 0]./255;

interval=[30 15 5 15 30 30 50];
mycolor=[];
for i=1:7
    temp=[];
    for j=1:3
        temp(:,j)=linspace(L(i,j),L(i+1,j),interval(i));
    end
    mycolor=[mycolor;temp];
end

%%
subplot('Position',[0.12 0.81 0.15 0.15]);
load('psi_2_1.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([154 45],[12 185],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.34,1.15,'II-1','Units', 'Normalized','fontsize',14)
text(-0.1,15,'(a)','Units', 'Normalized','fontsize',17)

subplot('Position',[0.34 0.81 0.15 0.15]);
load('psi_2_2.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([178 2],[115 115],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.34,1.15,'II-2','Units', 'Normalized','fontsize',14)

subplot('Position',[0.56 0.81 0.15 0.15]);
load('psi_2_3.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([177 4],[137 94],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.34,1.15,'II-3','Units', 'Normalized','fontsize',14)

subplot('Position',[0.78 0.81 0.15 0.15]);
load('psi_3_1.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([184 38],[64 179],'--','color',[0.3 0.3 0.3]);hold on
plot([38 104],[179 3],'--','color',[0.3 0.3 0.3]);hold on
plot([104 184],[3 64],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.33,1.15,'III-1','Units', 'Normalized','fontsize',14)

subplot('Position',[0.12 0.61 0.15 0.15]);
load('psi_3_2.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([141 139],[7 186],'--','color',[0.3 0.3 0.3]);hold on
plot([139 4],[186 121],'--','color',[0.3 0.3 0.3]);hold on
plot([4 141],[121 7],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.33,1.15,'III-2','Units', 'Normalized','fontsize',14)

subplot('Position',[0.34 0.61 0.15 0.15]);
load('psi_4_1.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([111 183],[3 59],'--','color',[0.3 0.3 0.3]);hold on
plot([183 114],[59 198],'--','color',[0.3 0.3 0.3]);hold on
plot([114 4],[198 127],'--','color',[0.3 0.3 0.3]);hold on
plot([4 111],[127 3],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.33,1.15,'IV-1','Units', 'Normalized','fontsize',14)

subplot('Position',[0.56 0.61 0.15 0.15]);
load('psi_4_2.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([151 165],[12 164],'--','color',[0.3 0.3 0.3]);hold on
plot([165 48],[164 189],'--','color',[0.3 0.3 0.3]);hold on
plot([48 9],[189 81],'--','color',[0.3 0.3 0.3]);hold on
plot([9 151],[81 12],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.33,1.15,'IV-2','Units', 'Normalized','fontsize',14)

subplot('Position',[0.78 0.61 0.15 0.15]);
load('psi_5.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);hold on
plot([147 123],[8 196],'--','color',[0.3 0.3 0.3]);hold on
plot([123 14],[196 71],'--','color',[0.3 0.3 0.3]);hold on
plot([14 180],[71 116],'--','color',[0.3 0.3 0.3]);hold on
plot([180 11],[116 151],'--','color',[0.3 0.3 0.3]);hold on
plot([11 147],[151 8],'--','color',[0.3 0.3 0.3]);hold on
view([90 -90])
axis off
text(0.36,1.15,'V','Units', 'Normalized','fontsize',14)

ax_c=subplot('Position',[0.14 0.1 0.65 0.5]);
load('confusion_matrix_shot1.mat')
M=confusion_matrix;
for i=1:8
    for j=1:8
        M(i,j)=M(i,j)/10^4;
    end
end
n1=0;
n2=128;
n3=255;
for i=1:8
    for j=1:8
        c1=M(i,j);
        color1=(1-c1)*(255-n1)+n1;
        color2=(1-c1)*(255-n2)+n2;
        color3=(1-c1)*(255-n3)+n3;
        fill([-0.5+i 0.5+i 0.5+i -0.5+i ],[-0.5+j -0.5+j 0.5+j 0.5+j ],[color1,color2,color3]./255);hold on
    end
end
axis([0.5 8.5 0.5 8.5])

mycolors(1:100,1)=linspace(255,n1)./255;
mycolors(1:100,2)=linspace(255,n2)./255;
mycolors(1:100,3)=linspace(255,n3)./255;
colormap(ax_c,mycolors);
colorbar('XTick',0:20:100,'XTickLabel',{'0%','20%','40%','60%','80%','100%'});
caxis([0,100])
xticks(1:8)
yticks(1:8)
xticklabels({'II-1','II-2','II-3','III-1','III-2','IV-1','IV-2','V'})
yticklabels({'II-1','II-2','II-3','III-1','III-2','IV-1','IV-2','V'})
xlabel('real','interpreter','latex')
ylabel('predict','interpreter','latex')
text(1,1,'Probability','Units', 'Normalized','fontsize',14,'interpreter','latex')
set(gca,'fontsize',14)
text(-0.1,1.7,'(a)','Units', 'Normalized','fontsize',17)
text(-0.1,1,'(b)','Units', 'Normalized','fontsize',17)
set(gcf,'position',[100 100 500 500])