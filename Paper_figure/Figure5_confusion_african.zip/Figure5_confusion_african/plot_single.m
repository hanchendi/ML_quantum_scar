clear
clc

%%
subplot('Position',[0.14 0.15 0.65 0.8]);
load('confusion_matrix_shot1.mat')
M=confusion_matrix;
for i=1:8
    for j=1:8
        M(i,j)=M(i,j)/10^4;
    end
end
n1=0;
n2=128;
n3=255;
for i=1:8
    for j=1:8
        c1=M(i,j);
        color1=(1-c1)*(255-n1)+n1;
        color2=(1-c1)*(255-n2)+n2;
        color3=(1-c1)*(255-n3)+n3;
        fill([-0.5+i 0.5+i 0.5+i -0.5+i ],[-0.5+j -0.5+j 0.5+j 0.5+j ],[color1,color2,color3]./255);hold on
    end
end
axis([0.5 8.5 0.5 8.5])
colorbar('XTick',0:20:100,'XTickLabel',{'0%','20%','40%','60%','80%','100%'});
mycolors(1:100,1)=linspace(255,n1)./255;
mycolors(1:100,2)=linspace(255,n2)./255;
mycolors(1:100,3)=linspace(255,n3)./255;
colormap(mycolors);
caxis([0,100])
xticks(1:8)
yticks(1:8)
xticklabels({'II-1','II-2','II-3','III-1','III-2','IV-1','IV-2','IV-3','V'})
yticklabels({'II-1','II-2','II-3','III-1','III-2','IV-1','IV-2','IV-3','V'})
xlabel('real','interpreter','latex')
ylabel('predict','interpreter','latex')
text(1,1,'Probability','Units', 'Normalized','fontsize',14,'interpreter','latex')
set(gca,'fontsize',14)
set(gcf,'position',[100 100 500 350])