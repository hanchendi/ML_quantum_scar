clear
clc


L=[102 178 255;
    153 204 255;
    204 229 255;
255 229 204;
255 204 153;
255 178 102;
255 153 51
255 128 0]./255;

interval=[30 15 5 15 30 30 50];
mycolor=[];
for i=1:7
    temp=[];
    for j=1:3
        temp(:,j)=linspace(L(i,j),L(i+1,j),interval(i));
    end
    mycolor=[mycolor;temp];
end

%%
subplot('Position',[0.1 0.89 0.14 0.11]);
load('psi_0.25_6105.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.25 0.89 0.14 0.11]);
load('psi_0.25_6114.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.4 0.89 0.14 0.11]);
load('psi_0.25_6135.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.55 0.89 0.14 0.11]);
load('psi_0.25_6152.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.7 0.89 0.14 0.11]);
load('psi_0.25_6154.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.85 0.89 0.14 0.11]);
load('psi_0.25_6186.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

%%
subplot('Position',[0.15 0.58 0.8 0.3]);
load('probability_sweep_025.mat')

index_begin=6101;
index_end=6200;
N=index_end-index_begin+1;

A=ones(N,8);
for i=1:10
    for j=index_begin:index_end
        
        p=probability_pred(i,j,:);
        p=reshape(p,[1,8]);
        norm=0;
        for k=1:8
            norm=norm+exp(p(k));
        end
        p_norm=zeros(1,8);
        for k=1:8
            p_norm(k)=exp(p(k))/norm;
        end
        for k=1:8
            A(j-index_begin+1,k)=A(j-index_begin+1,k)*p_norm(k);
        end
    end
end

for i=1:N
    
    index=find(A(i,:)==max(A(i,:)));
    if index==1
        h1=semilogy(i+index_begin-1,max(A(i,:)),'o','markersize',9,'MarkerFaceColor',[204 153 255]/255,'MarkerEdgeColor',[153 51 255]/255);hold on
    elseif index==2
        h2=semilogy(i+index_begin-1,max(A(i,:)),'o','markersize',9,'MarkerFaceColor',[153 153 255]/255,'MarkerEdgeColor',[51 51 255]/255);hold on
    elseif index==3
        h3=semilogy(i+index_begin-1,max(A(i,:)),'o','markersize',9,'MarkerFaceColor',[153 204 255]/255,'MarkerEdgeColor',[51 153 255]/255);hold on
    elseif index==4
        h4=semilogy(i+index_begin-1,max(A(i,:)),'V','markersize',10,'MarkerFaceColor',[0 255 128]/255,'MarkerEdgeColor',[0 153 76]/255);hold on
    elseif index==5
        h5=semilogy(i+index_begin-1,max(A(i,:)),'V','markersize',10,'MarkerFaceColor',[128 255 0]/255,'MarkerEdgeColor',[102 204 0]/255);hold on
    elseif index==6
        h6=semilogy(i+index_begin-1,max(A(i,:)),'s','markersize',12,'MarkerFaceColor',[255 255 0]/255,'MarkerEdgeColor',[204 204 0]/255);hold on
	elseif index==7
        h7=semilogy(i+index_begin-1,max(A(i,:)),'s','markersize',12,'MarkerFaceColor',[255 204 153]/255,'MarkerEdgeColor',[255 153 51]/255);hold on
	elseif index==8
        h8=semilogy(i+index_begin-1,max(A(i,:)),'p','markersize',12,'MarkerFaceColor',[255 153 153]/255,'MarkerEdgeColor',[255 51 51]/255);hold on
    end
end

h1=semilogy(i+index_begin-1,0,'o','markersize',9,'MarkerFaceColor',[204 153 255]/255,'MarkerEdgeColor',[153 51 255]/255);hold on
h2=semilogy(i+index_begin-1,0,'o','markersize',9,'MarkerFaceColor',[153 153 255]/255,'MarkerEdgeColor',[51 51 255]/255);hold on
h3=semilogy(i+index_begin-1,0,'o','markersize',9,'MarkerFaceColor',[153 204 255]/255,'MarkerEdgeColor',[51 153 255]/255);hold on
h4=semilogy(i+index_begin-1,0,'V','markersize',10,'MarkerFaceColor',[0 255 128]/255,'MarkerEdgeColor',[0 153 76]/255);hold on
h5=semilogy(i+index_begin-1,0,'V','markersize',10,'MarkerFaceColor',[128 255 0]/255,'MarkerEdgeColor',[102 204 0]/255);hold on
h6=semilogy(i+index_begin-1,0,'s','markersize',12,'MarkerFaceColor',[255 255 0]/255,'MarkerEdgeColor',[204 204 0]/255);hold on
h7=semilogy(i+index_begin-1,0,'s','markersize',12,'MarkerFaceColor',[255 204 153]/255,'MarkerEdgeColor',[255 153 51]/255);hold on
h8=semilogy(i+index_begin-1,0,'p','markersize',12,'MarkerFaceColor',[255 153 153]/255,'MarkerEdgeColor',[255 51 51]/255);hold on
plot([index_begin-1 index_end],[2*10^(-3) 2*10^(-3)],'k--');
text(-0.18,1,'(a)','Units', 'Normalized','fontsize',17)
annotation('textarrow',[0.1 0.5],[0.1 0.5],'color',[0 0 0]./255,'HeadStyle','none','linestyle','--');
h=legend([h1 h2 h3 h4 h5 h6 h7 h8],'II-1','II-2','II-3','III-1','III-2','IV-1','IV-2','V');
set(h,'interpreter','latex','location','southwest')
set(gca,'fontsize',15)
axis([6100 6200 10^(-8) 1])
set(h,'interpreter','latex','location','southwest')
set(gca,'fontsize',14)
xlabel('$n$','interpreter','latex')
ylabel('$\xi$','interpreter','latex')

%%
subplot('Position',[0.1 0.39 0.14 0.11]);
load('psi_0.25_8415.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.25 0.39 0.14 0.11]);
load('psi_0.25_8437.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.4 0.39 0.14 0.11]);
load('psi_0.25_8439.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.55 0.39 0.14 0.11]);
load('psi_0.25_8461.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.7 0.39 0.14 0.11]);
load('psi_0.25_8482.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

subplot('Position',[0.85 0.39 0.14 0.11]);
load('psi_0.25_8495.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;
colormap(mycolor);
view([90 -90])
axis off

%%
subplot('Position',[0.15 0.08 0.8 0.3]);
load('probability_sweep_025.mat')

index_begin=8401;
index_end=8500;
N=index_end-index_begin+1;

A=ones(N,8);
for i=1:10
    for j=index_begin:index_end
        
        p=probability_pred(i,j,:);
        p=reshape(p,[1,8]);
        norm=0;
        for k=1:8
            norm=norm+exp(p(k));
        end
        p_norm=zeros(1,8);
        for k=1:8
            p_norm(k)=exp(p(k))/norm;
        end
        for k=1:8
            A(j-index_begin+1,k)=A(j-index_begin+1,k)*p_norm(k);
        end
    end
end

for i=1:N
    
    index=find(A(i,:)==max(A(i,:)));
    if index==1
        h1=semilogy(i+index_begin-1,max(A(i,:)),'o','markersize',9,'MarkerFaceColor',[204 153 255]/255,'MarkerEdgeColor',[153 51 255]/255);hold on
    elseif index==2
        h2=semilogy(i+index_begin-1,max(A(i,:)),'o','markersize',9,'MarkerFaceColor',[153 153 255]/255,'MarkerEdgeColor',[51 51 255]/255);hold on
    elseif index==3
        h3=semilogy(i+index_begin-1,max(A(i,:)),'o','markersize',9,'MarkerFaceColor',[153 204 255]/255,'MarkerEdgeColor',[51 153 255]/255);hold on
    elseif index==4
        h4=semilogy(i+index_begin-1,max(A(i,:)),'V','markersize',10,'MarkerFaceColor',[0 255 128]/255,'MarkerEdgeColor',[0 153 76]/255);hold on
    elseif index==5
        h5=semilogy(i+index_begin-1,max(A(i,:)),'V','markersize',10,'MarkerFaceColor',[128 255 0]/255,'MarkerEdgeColor',[102 204 0]/255);hold on
    elseif index==6
        h6=semilogy(i+index_begin-1,max(A(i,:)),'s','markersize',12,'MarkerFaceColor',[255 255 0]/255,'MarkerEdgeColor',[204 204 0]/255);hold on
	elseif index==7
        h7=semilogy(i+index_begin-1,max(A(i,:)),'s','markersize',12,'MarkerFaceColor',[255 204 153]/255,'MarkerEdgeColor',[255 153 51]/255);hold on
	elseif index==8
        h8=semilogy(i+index_begin-1,max(A(i,:)),'p','markersize',12,'MarkerFaceColor',[255 153 153]/255,'MarkerEdgeColor',[255 51 51]/255);hold on
    end
end

h1=semilogy(i+index_begin-1,0,'o','markersize',9,'MarkerFaceColor',[204 153 255]/255,'MarkerEdgeColor',[153 51 255]/255);hold on
h2=semilogy(i+index_begin-1,0,'o','markersize',9,'MarkerFaceColor',[153 153 255]/255,'MarkerEdgeColor',[51 51 255]/255);hold on
h3=semilogy(i+index_begin-1,0,'o','markersize',9,'MarkerFaceColor',[153 204 255]/255,'MarkerEdgeColor',[51 153 255]/255);hold on
h4=semilogy(i+index_begin-1,0,'V','markersize',10,'MarkerFaceColor',[0 255 128]/255,'MarkerEdgeColor',[0 153 76]/255);hold on
h5=semilogy(i+index_begin-1,0,'V','markersize',10,'MarkerFaceColor',[128 255 0]/255,'MarkerEdgeColor',[102 204 0]/255);hold on
h6=semilogy(i+index_begin-1,0,'s','markersize',12,'MarkerFaceColor',[255 255 0]/255,'MarkerEdgeColor',[204 204 0]/255);hold on
h7=semilogy(i+index_begin-1,0,'s','markersize',12,'MarkerFaceColor',[255 204 153]/255,'MarkerEdgeColor',[255 153 51]/255);hold on
h8=semilogy(i+index_begin-1,0,'p','markersize',12,'MarkerFaceColor',[255 153 153]/255,'MarkerEdgeColor',[255 51 51]/255);hold on
plot([index_begin-1 index_end],[2*10^(-3) 2*10^(-3)],'k--');
text(-0.18,1,'(b)','Units', 'Normalized','fontsize',17)
h=legend([h1 h2 h3 h4 h5 h6 h7 h8],'II-1','II-2','II-3','III-1','III-2','IV-1','IV-2','V');
set(h,'interpreter','latex','location','southwest')
set(gca,'fontsize',15)
axis([8400 8500 10^(-8) 1])
set(h,'interpreter','latex','location','southwest')
set(gca,'fontsize',14)
xlabel('$n$','interpreter','latex')
ylabel('$\xi$','interpreter','latex')
set(gcf,'position',[100 100 500 700])