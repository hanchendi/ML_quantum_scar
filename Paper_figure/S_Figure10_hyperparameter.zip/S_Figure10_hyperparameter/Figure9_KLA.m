clear
clc

load('shot1_Heart_accuracy.mat')
n=length(result(:,1));
m=1;
for i=2:n
    if result(i,1)~=0
        m=m+1;
    end
end
l_average=200;
s1=0;
s2=0;
for i=1:m

    plot_result(i,1)=mean(result(max(1,i-l_average):i,2));
    plot_result(i,2)=mean(result(max(1,i-l_average):i,3));

end

semilogy((1:m)*10,(1-plot_result(:,1)),'linewidth',1.5,'color',[31 119 180]/255);hold on

load('shot2_Heart_accuracy.mat')
n=length(result(:,1));
m=1;
for i=2:n
    if result(i,1)~=0
        m=m+1;
    end
end
l_average=200;
s1=0;
s2=0;
for i=1:m

    plot_result(i,1)=mean(result(max(1,i-l_average):i,2));
    plot_result(i,2)=mean(result(max(1,i-l_average):i,3));

end

semilogy((1:m)*10,(1-plot_result(:,1)),'linewidth',1.5,'color',[255 127 14]/255);hold on

load('shot5_Heart_accuracy.mat')
n=length(result(:,1));
m=1;
for i=2:n
    if result(i,1)~=0
        m=m+1;
    end
end
l_average=200;
s1=0;
s2=0;
for i=1:m

    plot_result(i,1)=mean(result(max(1,i-l_average):i,2));
    plot_result(i,2)=mean(result(max(1,i-l_average):i,3));

end

semilogy((1:m)*10,(1-plot_result(:,1)),'linewidth',1.5,'color',[44 160 44]/255);hold on
h=legend('$K=1$','$K=2$','$K=5$');
set(h,'interpreter','latex')
xlabel("epoch",'interpreter','latex')
ylabel('Error','interpreter','latex')
set(gca,'fontsize',14)
axis([0 10000 0.09 1])
