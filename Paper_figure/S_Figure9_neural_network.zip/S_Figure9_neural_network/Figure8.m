clear
clc

subplot('Position',[0.13 0.59 0.35 0.35]);

img = imread('0394_17.png');
pcolor(img);
colormap(gray)
shading flat
xticks([])
yticks([])
set(gca,'fontsize',14)
text(-0.28,1,'(a)','Units', 'Normalized','fontsize',17)

subplot('Position',[0.62 0.59 0.35 0.35]);

img = imread('converted.png');
pcolor(img);
colormap(gray)
shading flat
xticks([])
yticks([])
set(gca,'fontsize',14)
text(-0.28,1,'(b)','Units', 'Normalized','fontsize',17)

ttt=subplot('Position',[0.13 0.075 0.35 0.402]);

load('psi_0.5_8480.mat')
psi1(psi1==psi1(1,1))=NaN;
psi2(psi2==psi2(1,1))=NaN;
psi=abs(psi1).^2+abs(psi2).^2;
pcolor(psi);shading flat;

L=[102 178 255;
    153 204 255;
    204 229 255;
255 229 204;
255 204 153;
255 178 102;
255 153 51
255 128 0]./255;

interval=[30 15 5 15 30 30 50];
mycolor=[];
for i=1:7
    temp=[];
    for j=1:3
        temp(:,j)=linspace(L(i,j),L(i+1,j),interval(i));
    end
    mycolor=[mycolor;temp];
end
axis off
colormap(ttt,mycolor);
view([90 -90])
set(gca,'fontsize',14)
text(-0.28,1,'(c)','Units', 'Normalized','fontsize',17)

ttt=subplot('Position',[0.62 0.1 0.35 0.35]);

img = imread('converted_scar.png');
pcolor(img);
colormap(ttt,gray)
shading flat
xticks([])
yticks([])
view([90 -90])
set(gca,'fontsize',14)
text(-0.28,1,'(d)','Units', 'Normalized','fontsize',17)
set(gcf,'position',[100 100 500 500])