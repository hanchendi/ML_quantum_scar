clear
clc

A = dir('data');
for i=3:15002
    
    s=A(i).name;
    load(['data/',s])
    
    psi1(psi1==psi1(1,1))=0;
    psi2(psi2==psi2(1,1))=0;

    %psi=zeros(232,232);
    psi=abs(psi1).^2+abs(psi2).^2;
	C=psi;
    x=C;
    [~,idx] = sort(x(:));
    y_max=x(idx(length(idx)-2000));
    for j1=1:202
        for j2=1:234
            if C(j1,j2)>y_max
                C(j1,j2)=0;
            else
                C(j1,j2)=1;
            end
        end
    end
    
    index=s(10:length(s)-4);
    while strlength(index)<5
        index="0"+index;
    end
    index=char(index);
    imwrite(C, ['Figure_train/psi_0.25_',index,'.png']);
    disp(i)
end